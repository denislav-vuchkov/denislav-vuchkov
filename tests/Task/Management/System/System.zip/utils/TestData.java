package Task.Management.System.utils;

import static Task.Management.System.models.CarImpl.CAR_SEATS_MIN;
import static Task.Management.System.models.CommentImpl.CONTENT_LEN_MIN;
import static Task.Management.System.models.ModelConstants.*;
import static Task.Management.System.models.MotorcycleImpl.CATEGORY_LEN_MIN;
import static Task.Management.System.models.TruckImpl.WEIGHT_CAP_MIN;
import static Task.Management.System.models.UserImpl.*;

public class TestData {

    public static class VehicleBase {
        public static final String VALID_MAKE = TestUtilities.initializeStringWithSize(MAKE_NAME_LEN_MIN + 1);
        public static final String VALID_MODEL = TestUtilities.initializeStringWithSize(MODEL_NAME_LEN_MIN + 1);
        public static final double VALID_PRICE = PRICE_VAL_MIN + 1;
    }

    public static class Motorcycle {
        public static final String VALID_CATEGORY = TestUtilities.initializeStringWithSize(CATEGORY_LEN_MIN + 1);
    }

    public static class Truck {
        public static final int VALID_WEIGHT_CAP = WEIGHT_CAP_MIN + 1;
    }

    public static class Car {
        public static final int VALID_SEATS = CAR_SEATS_MIN + 1;
    }

    public static class Comment {
        public static final String VALID_CONTENT = TestUtilities.initializeStringWithSize(CONTENT_LEN_MIN + 1);
    }

    public static class User {
        public static final String VALID_USERNAME = TestUtilities.initializeStringWithSize(USERNAME_LEN_MIN + 1);
        public static final String VALID_PASSWORD = TestUtilities.initializeStringWithSize(PASSWORD_LEN_MIN + 1);
        public static final String VALID_FIRST_NAME = TestUtilities.initializeStringWithSize(FIRSTNAME_LEN_MIN + 1);
        public static final String VALID_LAST_NAME = TestUtilities.initializeStringWithSize(LASTNAME_LEN_MIN + 1);
    }
}