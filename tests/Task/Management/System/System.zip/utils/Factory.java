package Task.Management.System.utils;

import Task.Management.System.models.*;
import Task.Management.System.models.contracts.*;
import com.telerikacademy.oop.dealership.models.*;
import Task.Management.System.models.enums.UserRole;
import com.telerikacademy.oop.dealership.models.contracts.*;

import static Task.Management.System.utils.TestData.Car.VALID_SEATS;
import static Task.Management.System.utils.TestData.Comment.VALID_CONTENT;
import static Task.Management.System.utils.TestData.Motorcycle.VALID_CATEGORY;
import static Task.Management.System.utils.TestData.Truck.VALID_WEIGHT_CAP;
import static Task.Management.System.utils.TestData.User.*;
import static Task.Management.System.utils.TestData.User.VALID_PASSWORD;
import static Task.Management.System.utils.TestData.VehicleBase.*;

public class Factory {

    public static Car createCar() {
        return new CarImpl(VALID_MAKE, VALID_MODEL, VALID_PRICE, VALID_SEATS);
    }

    public static User createNormalUser() {
        return new UserImpl(VALID_USERNAME, VALID_FIRST_NAME, VALID_LAST_NAME, VALID_PASSWORD, UserRole.NORMAL);
    }

    public static Motorcycle createMotorcycle() {
        return new MotorcycleImpl(VALID_MAKE, VALID_MODEL, VALID_PRICE, VALID_CATEGORY);
    }

    public static Truck createTruck() {
        return new TruckImpl(VALID_MAKE, VALID_MODEL, VALID_PRICE, VALID_WEIGHT_CAP);
    }

    public static Comment createComment(User user) {
        return new CommentImpl(VALID_CONTENT, user.getUsername());
    }

}
