package Task.Management.System.commands;

import Task.Management.System.commands.contracts.Command;
import Task.Management.System.core.CommandFactoryImpl;
import Task.Management.System.core.TaskManagementSystemRepositoryImpl;
import Task.Management.System.core.contracts.CommandFactory;
import Task.Management.System.core.contracts.VehicleDealershipRepository;
import Task.Management.System.models.UserImpl;
import Task.Management.System.models.contracts.User;
import Task.Management.System.models.enums.UserRole;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static Task.Management.System.utils.TestData.User.*;
import static Task.Management.System.utils.TestData.User.VALID_PASSWORD;

public class Logout_Tests {
    private VehicleDealershipRepository vehicleDealershipRepository;
    private CommandFactory commandFactory;

    @BeforeEach
    public void before() {
        commandFactory = new CommandFactoryImpl();
        vehicleDealershipRepository = new TaskManagementSystemRepositoryImpl();
    }

    @Test
    public void execute_ShouldLogoutUser() {
        // Arrange
        User userToLogIn = new UserImpl(VALID_USERNAME, VALID_FIRST_NAME, VALID_LAST_NAME, VALID_PASSWORD, UserRole.NORMAL);
        vehicleDealershipRepository.login(userToLogIn);
        Command logout = commandFactory.createCommandFromCommandName("logout", vehicleDealershipRepository);

        // Act
        logout.execute(new ArrayList<>());

        // Assert
        Assertions.assertThrows(IllegalArgumentException.class, () -> vehicleDealershipRepository.getLoggedInUser());
    }
}
