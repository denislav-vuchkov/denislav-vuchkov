package Task.Management.System.commands;

import Task.Management.System.commands.contracts.Command;
import Task.Management.System.core.CommandFactoryImpl;
import Task.Management.System.core.TaskManagementSystemRepositoryImpl;
import Task.Management.System.core.contracts.CommandFactory;
import Task.Management.System.core.contracts.VehicleDealershipRepository;
import Task.Management.System.models.UserImpl;
import Task.Management.System.models.contracts.User;
import Task.Management.System.models.enums.UserRole;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static Task.Management.System.utils.TestData.User.*;
import static Task.Management.System.utils.TestData.User.VALID_PASSWORD;

public class Login_Tests {
    private VehicleDealershipRepository vehicleDealershipRepository;
    private CommandFactory commandFactory;

    @BeforeEach
    public void before() {
        this.commandFactory = new CommandFactoryImpl();
        this.vehicleDealershipRepository = new TaskManagementSystemRepositoryImpl();
    }

    @Test
    public void execute_ShouldLoginUser_WhenUserNotLoggedIn() {
        // Arrange
        User userToLogIn = new UserImpl(VALID_USERNAME, VALID_FIRST_NAME, VALID_LAST_NAME, VALID_PASSWORD, UserRole.NORMAL);
        vehicleDealershipRepository.addUser(userToLogIn);
        Command login = commandFactory.createCommandFromCommandName("Login", vehicleDealershipRepository);
        List<String> params = List.of(userToLogIn.getUsername(), userToLogIn.getPassword());

        // Act
        login.execute(params);

        // Assert
        Assertions.assertEquals(userToLogIn.getUsername(), vehicleDealershipRepository.getLoggedInUser().getUsername());
    }

    @Test
    public void execute_ShouldThrow_WhenPasswordIsWrong() {
        // Arrange
        User userToLogIn = new UserImpl(VALID_USERNAME, VALID_FIRST_NAME, VALID_LAST_NAME, VALID_PASSWORD, UserRole.NORMAL);
        vehicleDealershipRepository.addUser(userToLogIn);
        Command login = commandFactory.createCommandFromCommandName("Login", vehicleDealershipRepository);
        List<String> params = List.of(userToLogIn.getUsername(), "WRONGPASSWORD");

        // Act, Assert
        Assertions.assertThrows(IllegalArgumentException.class, () -> login.execute(params));
    }

    @Test
    public void execute_ShouldThrow_WhenUserDoesNotExists() {
        // Arrange
        Command login = commandFactory.createCommandFromCommandName("Login", vehicleDealershipRepository);
        List<String> params = List.of(VALID_USERNAME, VALID_PASSWORD);

        // Act, Assert
        Assertions.assertThrows(IllegalArgumentException.class, () -> login.execute(params));
    }

    @Test
    public void execute_ShouldThrow_WhenUserAlreadyLoggedIn() {
        // Arrange
        User userToLogIn = new UserImpl(VALID_USERNAME, VALID_FIRST_NAME, VALID_LAST_NAME, VALID_PASSWORD, UserRole.NORMAL);
        vehicleDealershipRepository.addUser(userToLogIn);
        Command login = commandFactory.createCommandFromCommandName("Login", vehicleDealershipRepository);
        List<String> params = List.of(userToLogIn.getUsername(), userToLogIn.getPassword());

        // Act
        login.execute(params);

        // Assert
        Assertions.assertThrows(IllegalArgumentException.class, () -> login.execute(params));
    }
}
