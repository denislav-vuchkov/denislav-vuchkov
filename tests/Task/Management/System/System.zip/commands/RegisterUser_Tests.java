package Task.Management.System.commands;

import Task.Management.System.commands.contracts.Command;
import Task.Management.System.core.CommandFactoryImpl;
import Task.Management.System.core.TaskManagementSystemRepositoryImpl;
import Task.Management.System.core.contracts.CommandFactory;
import Task.Management.System.core.contracts.VehicleDealershipRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static Task.Management.System.utils.TestData.User.*;

public class RegisterUser_Tests {

    private VehicleDealershipRepository vehicleDealershipRepository;
    private CommandFactory commandFactory;

    @BeforeEach
    public void before() {
        this.commandFactory = new CommandFactoryImpl();
        this.vehicleDealershipRepository = new TaskManagementSystemRepositoryImpl();
    }

    @Test
    public void createUser_ShouldCreate_WhenInputIsValid() {
        // Arrange
        Command createCommand = commandFactory.createCommandFromCommandName("RegisterUser",
                vehicleDealershipRepository);
        List<String> params = List.of(VALID_USERNAME, VALID_FIRST_NAME, VALID_LAST_NAME, VALID_PASSWORD);

        // Act
        createCommand.execute(params);

        //Assert
        Assertions.assertEquals(vehicleDealershipRepository.getUsers().size(), 1);
        Assertions.assertEquals(vehicleDealershipRepository.getUsers().get(0).getUsername(), VALID_USERNAME);

    }

    @Test
    public void Execute_ShouldThrow_WhenUserAlreadyExist() {
        // Arrange
        Command registerUser = commandFactory.createCommandFromCommandName("registeruser", vehicleDealershipRepository);
        List<String> params = List.of(VALID_USERNAME, VALID_FIRST_NAME, VALID_LAST_NAME, VALID_PASSWORD);

        // Act
        registerUser.execute(params);

        // Assert
        Assertions.assertThrows(IllegalArgumentException.class, () -> registerUser.execute(params));
    }
}
